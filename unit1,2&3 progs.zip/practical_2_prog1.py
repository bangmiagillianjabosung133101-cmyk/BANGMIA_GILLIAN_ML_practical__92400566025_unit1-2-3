# attribute 
import pandas as pd 
data = pd.read_csv('airlines.csv')

print(data.columns)

for column in data.columns:
    print(data[column].dtype)

for column in data.columns:
    print(f"Unique values in {column}: {data[column].unique()}")