import pandas as pd 
from sklearn.preprocessing import StandardScaler 

data = pd.read_csv('airlines.csv')
data_clean = data.dropna()

data_clean['Active_Encoded'] = data_clean['Active'].map({'Y':1, 'N':0})

df_encoded = pd.get_dummies(data_clean, columns=['Country'], prefix='Country')

scaler = StandardScaler()
df_encoded['Airline_ID_Scaled'] = scaler.fit_transform(df_encoded[['Airline ID']])
print(df_encoded.head())