import pandas as pd

# text file 
data_txt = pd.read_table("data.txt")
print(data_txt.head())

# xml file 
data_xml = pd.read_xml("data.xml")
print(data_xml)

# json file 
data_json = pd.read_json("data.json")
print(data_json.head())