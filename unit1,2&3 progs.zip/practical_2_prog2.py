# data cleaning 
import pandas as pd 
import numpy as np

data = pd.read_csv('airlines.csv')
data = data.dropna()

print(len(data))
print(data.head())