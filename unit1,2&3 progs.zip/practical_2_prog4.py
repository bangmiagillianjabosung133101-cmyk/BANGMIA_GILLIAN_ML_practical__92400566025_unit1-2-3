import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler


df = pd.read_csv('airlines.csv')
df_reduced = df[['Country', 'Active']].dropna()


df_reduced['Active'] = df_reduced['Active'].map({'Y': 1, 'N': 0})
df_encoded = pd.get_dummies(df_reduced, columns=['Country'])


scaler = StandardScaler()
X_scaled = scaler.fit_transform(df_encoded.drop('Active', axis=1))


pca = PCA(n_components=10)
X_pca = pca.fit_transform(X_scaled)


print(f"Original feature count: {df_encoded.shape[1]}")
print(f"Reduced feature count: {X_pca.shape[1]}")
print(f"Total variance explained by these 10 components: {sum(pca.explained_variance_ratio_)*100:.2f}%")
