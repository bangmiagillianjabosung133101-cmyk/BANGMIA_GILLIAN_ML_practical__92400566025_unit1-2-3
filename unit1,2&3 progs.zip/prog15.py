import numpy as np
data = b'hello'
arr = np.frombuffer(data,type)
print(arr)