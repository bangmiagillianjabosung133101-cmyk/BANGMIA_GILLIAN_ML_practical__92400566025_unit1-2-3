# scalling the data using standard scaler
import pandas as pd 
import numpy as np
from sklearn.preprocessing import StandardScaler

data = pd.read_csv('auto-mpg.csv')
data = data.replace('?', np.nan)
data = data.dropna()

X = data.drop(['mpg', 'car_name'], axis=1)

scaler = StandardScaler()
scaledData = scaler.fit_transform(X)
print(scaledData)