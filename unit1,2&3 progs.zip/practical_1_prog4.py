import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

data = pd.read_csv('auto-mpg.csv')
data = data.replace('?', np.nan)
data = data.dropna()
X = data.drop(['mpg', 'car_name'], axis=1)
scaler = StandardScaler()
scaledData = scaler.fit_transform(X)

pca = PCA(n_components=2)
pcaData = pca.fit_transform(scaledData)

pca_df = pd.DataFrame(data=pcaData, columns=['Principal Component 1', 'Principal Component 2'])
print(pca_df.head())

print("Explained variance ratio:", pca.explained_variance_ratio_)
print("Total explained variance:", np.sum(pca.explained_variance_ratio_))