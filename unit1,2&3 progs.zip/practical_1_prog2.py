import pandas as pd 
import numpy as np

data = pd.read_csv('auto-mpg.csv')

column_names = data.columns 
print(column_names)

print(data.isnull().sum())