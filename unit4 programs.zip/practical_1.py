import pandas as pd

from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

data = pd.read_csv('buy_computer.csv')

# One-hot encoding
data = pd.get_dummies(data, drop_first=True)

y = data['Buyscomputer_Yes']
X = data.drop('Buyscomputer_Yes', axis=1)

model = GaussianNB()
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)